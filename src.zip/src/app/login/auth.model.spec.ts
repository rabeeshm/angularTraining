import { Auth } from './auth.model';

describe('Auth', () => {
  it('should create an instance', () => {
    expect(new Auth()).toBeTruthy();
  });
});
