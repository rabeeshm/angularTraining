import { Profile } from './profile.model';

describe('Profile', () => {
  it('should create an instance', () => {
    expect(new Profile()).toBeTruthy();
  });
});
